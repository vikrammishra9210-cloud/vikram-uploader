# minimal utils placeholder
def progress_bar(*args, **kwargs):
    return None
